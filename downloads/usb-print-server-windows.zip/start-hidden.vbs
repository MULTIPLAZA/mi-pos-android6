' Lanza usb-print-server.exe SIN mostrar la ventana de consola.
' Windows ejecuta este .vbs invisible y el agente queda en background.
Set sh = WScript.CreateObject("WScript.Shell")
sh.CurrentDirectory = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
sh.Run """" & sh.CurrentDirectory & "\usb-print-server.exe""", 0, False
