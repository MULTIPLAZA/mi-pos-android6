@echo off
title Instalador USB Print Server

echo ============================================================
echo  USB Print Server - Instalador
echo  Para impresoras termicas USB del POS mi-pos NODO
echo ============================================================
echo.

set "DEST=%LOCALAPPDATA%\NODOUsbPrintServer"
echo  Carpeta destino: %DEST%
echo.

if not exist "%DEST%" mkdir "%DEST%"

echo  [1/5] Cerrando versiones anteriores...
rem Tiene que ir ANTES de copiar -- si el agente viejo sigue corriendo, el
rem archivo .exe queda bloqueado y el copy /Y de abajo falla en silencio
rem ("El proceso no tiene acceso al archivo..."), dejando instalada la
rem misma version vieja aunque el instalador diga "OK" al final (confirmado
rem en vivo 2026-08-29, tenant lodefer@admin.com -- el mismo bug de
rem print-raw.ps1 seguia despues de "reinstalar" varias veces por esto).
taskkill /F /IM usb-print-server.exe 1>NUL 2>NUL
timeout /T 1 /NOBREAK 1>NUL

echo  [2/5] Copiando archivos...
copy /Y "%~dp0usb-print-server.exe" "%DEST%\usb-print-server.exe" 1>NUL
if errorlevel 1 (
  echo.
  echo ============================================================
  echo  ERROR - No se pudo copiar usb-print-server.exe
  echo ============================================================
  echo.
  echo  Puede seguir bloqueado por otro proceso. Reinicia la PC e
  echo  intenta de nuevo, o cierra manualmente "usb-print-server.exe"
  echo  desde el Administrador de tareas antes de reintentar.
  echo.
  pause
  exit /b 1
)
copy /Y "%~dp0start-hidden.vbs" "%DEST%\start-hidden.vbs" 1>NUL
copy /Y "%~dp0desinstalar.bat" "%DEST%\desinstalar.bat" 1>NUL 2>NUL

echo  [3/5] Configurando arranque automatico con Windows...
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "LNK=%STARTUP%\USB Print Server.lnk"

powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%LNK%'); $s.TargetPath='%DEST%\start-hidden.vbs'; $s.WorkingDirectory='%DEST%'; $s.Description='USB Print Server para mi-pos NODO'; $s.Save()" 1>NUL

echo  [4/5] Iniciando el agente en background...
wscript.exe "%DEST%\start-hidden.vbs"

echo  [5/5] Verificando...
timeout /T 2 /NOBREAK 1>NUL

powershell -NoProfile -Command "try { $r=Invoke-WebRequest -Uri 'http://127.0.0.1:9200/status' -UseBasicParsing -TimeoutSec 3; if($r.StatusCode -eq 200){exit 0} else {exit 1} } catch { exit 1 }"

if %ERRORLEVEL%==0 (
  echo.
  echo ============================================================
  echo  OK - INSTALADO Y FUNCIONANDO
  echo ============================================================
  echo.
  echo  El agente esta corriendo en background ^(invisible^).
  echo  Se va a arrancar solo cada vez que prendas la PC.
  echo.
  echo  Ahora anda al POS:
  echo    Configuracion - Impresoras - USB LOCAL
  echo    Elegi tu impresora termica de la lista.
  echo.
  echo  Para desinstalar: corre "desinstalar.bat" desde:
  echo    %DEST%
  echo.
) else (
  echo.
  echo ============================================================
  echo  ATENCION - El agente se copio pero no responde
  echo ============================================================
  echo.
  echo  Probar reiniciar la PC. Si sigue sin andar:
  echo    1. Anda a: %DEST%
  echo    2. Doble click en "usb-print-server.exe"
  echo    3. Si funciona, mandar captura al soporte.
  echo.
)

echo Presione cualquier tecla para cerrar este instalador...
pause 1>NUL
