@echo off
title Desinstalar USB Print Server

echo ============================================================
echo  USB Print Server - Desinstalar
echo ============================================================
echo.

set "DEST=%LOCALAPPDATA%\NODOUsbPrintServer"
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "LNK=%STARTUP%\USB Print Server.lnk"

echo  [1/3] Deteniendo el agente...
taskkill /F /IM usb-print-server.exe 1>NUL 2>NUL

echo  [2/3] Quitando del arranque de Windows...
if exist "%LNK%" del "%LNK%" 1>NUL

echo  [3/3] Borrando archivos...
if exist "%DEST%" rmdir /S /Q "%DEST%"

echo.
echo  OK Desinstalado.
echo.
pause
